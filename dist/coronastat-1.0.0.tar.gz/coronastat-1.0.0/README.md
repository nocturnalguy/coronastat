# coronastat
A simple CLI for visualising the different cases, mortality and natality rates etc live in the terminal or CMD or any console.

# Required dependencies
1. BeautifulSoup
2. Requests
3. Random
4. Terminaltables
5. Sys